# Deployment Guide
- Deploy frontend to Vercel
- Backend to Railway
- Contract to Solana