# Sends profit alerts to Telegram
print('Telegram bot ready.')